# Spring Boot Hello World Example Project  :-

Check is user login as a root user or not

apt-get update 

apt-get install maven

mvn test

mvn package

apt-get install tomcat9 

cp -rvf path_of_clone_repo_for_project_practical.war /var/lib/tomcat9/webapps/${APP_CONTEXT}.war
