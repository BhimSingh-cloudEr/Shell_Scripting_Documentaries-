#!/bin/bash

pass_args() {
    echo "First argument is : $1"
    echo "Second argument is : $2"
}

pass_args "Hello" "World"