#!/bin/bash

fruits=("Apple" "Banana" "Grapes" "Pears" "Cherry")
lenght=${#fruits[@]}
echo "Lenght of the given fruit's name are : ${lenght}"