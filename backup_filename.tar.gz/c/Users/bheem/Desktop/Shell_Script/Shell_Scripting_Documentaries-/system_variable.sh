#!/bin/bash

echo -e "$OSTYPE \n"

echo -e "$HOME \n "

echo -e "$PPID \n "

echo -e  "${$}  \n"

echo -e "$PWD \n"

echo -e "$HOSTNAME \n"

# echo $PATH \n