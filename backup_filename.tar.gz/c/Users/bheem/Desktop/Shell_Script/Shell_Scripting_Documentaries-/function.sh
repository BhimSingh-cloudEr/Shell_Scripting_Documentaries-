#!/bin/bash

function_name(){
    echo "Hii,Bhim Singh"
    echo "<-------------->"
    echo "How are you ?"    
}

function_name

function_name