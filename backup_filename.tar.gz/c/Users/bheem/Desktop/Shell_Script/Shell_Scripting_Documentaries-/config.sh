#!/bin/bash

# Configuration Setting Commands

DB_HOST="localhost"
DB_PORT="3306"
DB_USER="myuser"
DB_PASSWORD="mypassword"

