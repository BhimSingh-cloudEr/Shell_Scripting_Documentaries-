# Source of the configuration file

source config.sh

# Now you can use the variable from the configuration file

echo "Database host : ${DB_HOST}"

echo "Database host : ${DB_PORT}"

echo "Database host : ${DB_USER}"

echo "Database host : ${DB_PASSWORD}"

