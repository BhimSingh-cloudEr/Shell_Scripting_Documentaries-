#!/bin/bash

# Captalized and small the statements 

# Print as like given statement

string="Hii, this is a example to test style of the statement !"
echo "${string,}"

# Small all worlds  

string="Hii, this is a example to test style of the statement !"
echo "${string,,}"

# Captalized all words which are given by the user

string="Hii, this is a example to test style of the statement !"
echo "${string^^}"

string="Hii, this is a example to test style of the statement !"
echo "${string^}"