#!/bin/bash

# Infinite Loop

while true 
do
    echo "Hello, Everyone "
    sleep 2
done