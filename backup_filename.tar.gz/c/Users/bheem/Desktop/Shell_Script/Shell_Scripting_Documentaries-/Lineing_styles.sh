#!/bin/bash

# For next line

echo -e "This is a example for next line \n contents showing method ! "


# For the Tab space

echo -e "This is for tab \t method !"


# For vertical tab 

echo -e "Example for vertical tab  \v and showing next  \v content with different message !"