function myfunc() {
    echo "<---------->"
    echo "Hello world"
    echo "<---------->"
    echo "Hello world"
    echo "<***********>"
}

myfunc
myfunc
myfunc
myfunc